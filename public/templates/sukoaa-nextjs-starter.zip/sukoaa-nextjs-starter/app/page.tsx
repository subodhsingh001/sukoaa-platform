export default function Home(){return <main><p>YOUR NEXT IDEA STARTS HERE</p><h1>Hello, Sukoaa ✳</h1><p>Edit app/page.tsx to make it yours.</p></main>}
