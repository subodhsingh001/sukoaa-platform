# Sukoaa Next.js starter

Install Node.js 22 LTS or newer.

1. npm install
2. npm run dev
3. Open http://localhost:3000

This is a minimal local starter, not the complete Sukoaa platform. It has no AI or database connection. Review current package/security updates before a public deployment.
