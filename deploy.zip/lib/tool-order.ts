import {learningModules} from './learning/modules';
export const learningToolLinks=learningModules.map(m=>({id:m.id,name:m.name,icon:({fastapi:'FA',nodejs:'Node',postgresql:'PG',tailwindcss:'TW',php:'PHP',laravel:'L'} as const)[m.id],href:'/labs/'+m.id,info:m.id==='nodejs'?'Run Node.js · browser HTTP server':m.id==='postgresql'?'Run PostgreSQL · tables, queries and JSONB':m.id==='tailwindcss'?'Compile Tailwind CSS · live preview':m.id==='fastapi'?'Run FastAPI · routes, validation and responses':m.id==='laravel'?'Run Laravel · routes and HTTP responses':'Run PHP · code, output and errors'}));
export const toolOrder=['javascript','python','html-css','react','angular','nextjs','react-native','typescript','sql','json','notepad','c','cpp','rust','csharp','java'] as const;
export const toolLinks=[
 {id:'javascript',name:'JavaScript',icon:'JS',href:'/workspace?language=javascript',info:'Browser JavaScript · console and error locations'},
 {id:'python',name:'Python',icon:'Py',href:'/workspace?language=python',info:'Browser Python · standard input and console'},
 {id:'html',name:'HTML & CSS',icon:'<>',href:'/workspace?language=html',info:'HTML and CSS · live browser preview'},
 {id:'react',name:'React',icon:'⚛',href:'/studio?framework=react',info:'Multi-file React · imports, preview and console'},
 {id:'angular',name:'Angular',icon:'A',href:'/studio?framework=angular',info:'Angular 22 · CLI, modules, npm packages and preview'},
 {id:'nextjs',name:'Next.js',icon:'N',href:'/studio?framework=nextjs',info:'Next.js project · browser Node runtime requirements apply'},
 {id:'react-native',name:'React Native',icon:'RN',href:'/native',info:'React Native Web · local preview · optional Expo phone testing'},
 {id:'typescript',name:'TypeScript',icon:'TS',href:'/workspace?language=typescript',info:'Browser TypeScript · transpilation and console'},
 {id:'sql',name:'SQL / SQLite',icon:'SQL',href:'/workspace?language=sql',info:'SQLite queries · local browser database'},
 ...learningToolLinks,
 {id:'json',name:'JSON validator',icon:'{}',href:'/workspace?language=json',info:'Validate and format JSON'},
 {id:'go',name:'Go',icon:'Go',href:'/workspace?language=go',info:'Go execution · configured remote runner required'},
 {"id": "c", "name": "C", "icon": "C", "href": "/workspace?language=c", "info": "C \u00b7 isolated compiler; runner setup and sign-in required"},
 {"id": "cpp", "name": "C++", "icon": "C++", "href": "/workspace?language=cpp", "info": "C++ \u00b7 isolated compiler; runner setup and sign-in required"},
 {"id": "rust", "name": "Rust", "icon": "Rs", "href": "/workspace?language=rust", "info": "Rust \u00b7 isolated compiler; runner setup and sign-in required"},
 {"id": "csharp", "name": "C#", "icon": "C#", "href": "/workspace?language=csharp", "info": "C# \u00b7 isolated compiler; runner setup and sign-in required"},
 {"id": "java", "name": "Java", "icon": "Jv", "href": "/workspace?language=java", "info": "Java \u00b7 isolated compiler; runner setup and sign-in required"},
] as const;

export type ToolId = (typeof toolLinks)[number]["id"];
