import {redirect} from 'next/navigation';
export default function Setup(){redirect('/admin/setup')}
